<header style="background-color: #ffffff; height: 10vh;" class="rounded container nav-desktop">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container-fluid d-flex justify-content-between">
				<a class="navbar-brand" href="#">Tibirita</a>
				<a href="#">
					<form class="d-flex">
						<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
						<button class="btn btn-outline-success" type="submit">Search</button>
					</form>
				</a>
				<a class="navbar-brand" href="#"><i class="fa-regular fa-bell" aria-hidden="true"></i></a>
				<a class="" style="color: black;" aria-current="page" href="#"><i class="fa-regular fa-message me-2" aria-hidden="true"></i></a>
				<a class="navbar-brand" href="#">
					<img src="assets/imgs/xenomorfo.jpg" class="rounded-circle" style="width:50px;height:50px;" alt="">
				</a>
				<a class="navbar-brand" href="#"><i class="fa-solid fa-gear" aria-hidden="true"></i></a>
			</div>
		</nav>
	</header>